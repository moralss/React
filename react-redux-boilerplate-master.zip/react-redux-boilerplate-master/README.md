[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](https://raw.githubusercontent.com/edisonchee/slimbot/master/LICENSE)

# React-Redux Boilerplate

Running on:
* [React 16.9.0](https://github.com/facebook/react)
* [React-router-dom 5.0.1](https://github.com/ReactTraining/react-outer/tree/master/packages/react-router-dom)
* [React-redux 7.1.0](https://github.com/reactjs/react-redux)
* [Connected-react-router 6.5.2](https://github.com/supasate/connected-react-router)

Barebones boilerplate to get up and running real quick.
