export const updateName = text => ({
  type: 'UPDATE_NAME',
  text
})

export const clearName = () => ({
  type: 'CLEAR_NAME',
})